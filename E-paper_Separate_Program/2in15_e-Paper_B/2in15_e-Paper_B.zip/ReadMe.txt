中文：
使用方法详见中文Wiki
https://www.waveshare.net/wiki/3.52inch_e-Paper_HAT_(B)

English：
See the English Wiki for details
https://www.waveshare.com/wiki/3.52inch_e-Paper_HAT_(B)